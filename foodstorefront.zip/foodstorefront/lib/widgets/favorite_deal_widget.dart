import 'package:flutter/material.dart';

class FavoriteDealWidget extends StatefulWidget {
  const FavoriteDealWidget({super.key});

  @override
  State<FavoriteDealWidget> createState() => _FavoriteDealWidgetState();
}

class _FavoriteDealWidgetState extends State<FavoriteDealWidget> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
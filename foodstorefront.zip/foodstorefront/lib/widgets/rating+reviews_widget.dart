import 'package:flutter/material.dart';
import 'package:custom_rating_bar/custom_rating_bar.dart';
import 'package:foodstorefront/models/review_model.dart';
import 'package:foodstorefront/utils/colors.dart';

class rating_ReviewCard extends StatelessWidget {
  final ReviewModel review;

  const rating_ReviewCard({
    Key? key,
    required this.review,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Calculate time ago
    String timeAgo = getTimeAgo(review.reviewTime);

    return Card(
      
      color: MyColors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              review.reviewText,
              style: TextStyle(fontSize: 12, overflow: TextOverflow.ellipsis),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                RatingBar(
                  size: 15,
                  alignment: Alignment.center,
                  filledIcon: Icons.star,
                  emptyIcon: Icons.star_border,
                  emptyColor: MyColors.primary,
                  filledColor: Colors.amberAccent,
                  halfFilledIcon: Icons.star_half,
                  halfFilledColor: Colors.amberAccent,
                  initialRating: review.rating,
                  maxRating: 5,
                  onRatingChanged: (double) {},
                ),
                SizedBox(width: 8),
                Text(
                  review.reviewerName,
                  style: TextStyle(color: MyColors.greyText, fontSize: 12),
                ),
                SizedBox(width: 8),
                Text(
                  timeAgo,
                  style: TextStyle(color: MyColors.greyText, fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String getTimeAgo(DateTime reviewTime) {
    Duration timeDifference = DateTime.now().difference(reviewTime);
    if (timeDifference.inDays > 0) {
      return '${timeDifference.inDays}d ago';
    } else if (timeDifference.inHours > 0) {
      return '${timeDifference.inHours}h ago';
    } else if (timeDifference.inMinutes > 0) {
      return '${timeDifference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}

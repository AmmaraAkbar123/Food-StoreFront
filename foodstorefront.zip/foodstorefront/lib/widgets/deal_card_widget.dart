import 'package:flutter/material.dart';
import 'package:foodstorefront/models/product_model.dart';
import 'package:foodstorefront/utils/colors.dart';
import 'package:foodstorefront/widgets/stack_image_add_icon_widget.dart';

class DealCard extends StatelessWidget {
  final Product product;

  DealCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold),
                ),
                Row(
                  children: [
                    Text(
                      'Rs. ${product.price}',
                      style: const TextStyle(
                          fontSize: 15, color: MyColors.primary),
                    ),
                    const SizedBox(width: 10),
                    if (product.oldPrice != null)
                      Text(
                        'Rs. ${product.oldPrice}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  child: Text(
                    product.description,
                    style: const TextStyle(
                        fontSize: 12,
                        overflow: TextOverflow.clip,
                        color: MyColors.greyText),
                  ),
                ),
                if (product.isPopular)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.whatshot,
                          color: MyColors.red,
                          size: 14,
                        ),
                        const SizedBox(width: 5),
                        Text(
                          'Popular',
                          style:
                              TextStyle(color: MyColors.greyText, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: SizedBox(
                child: StackImagewithAddIconWidget(productImage: product.imageUrl)),
          ),
        ],
      ),
    );
  }
}

class ImagesStrings {
  //
  static const String appLogo = "assets/images/pandasplash.png";
  static const String location = "assets/images/location.png";
  static const String optpLogo = "assets/images/optp.jpg";
  static const String burgerimage = "assets/images/chicken_tikka.jpg";
  static const String burgerimage2 = "assets/images/cricket_deal_2.jpg";

//
}
